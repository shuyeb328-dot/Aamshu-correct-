# Build Aamshu APK with GitHub Actions

The repository contains two workflows:

- **Aamshu Android APK**: runs on pushes to `main` and can also be started manually. It produces a debug APK and attempts a release APK candidate.
- **Aamshu Android AAB**: manually started from GitHub Actions and produces a release AAB candidate.

## Phone-only steps

1. Open the Aamshu repository on GitHub.
2. Upload the contents of this project to the repository root and commit to `main`.
3. Open **Actions**.
4. Select **Aamshu Android APK**.
5. Tap **Run workflow** (or push to `main`).
6. Wait for the green check.
7. Open the workflow run and scroll to **Artifacts**.
8. Download `aamshu-...-debug-apk`.

The debug APK is suitable for installing/testing on an Android phone. It is not the final Play Store-signed release.

## Play Store release

The AAB workflow creates a release candidate. A production Play Store build should be signed with a protected Android upload key or produced through EAS/another signing service. Never commit a keystore or passwords to the repository.

## Required secrets

None for the initial debug APK workflow.

## Current app version

Aamshu Android is configured as version **4.6.0**, Android version code **18**.
