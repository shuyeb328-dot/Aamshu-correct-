import test from "node:test";
import assert from "node:assert/strict";
import {aiStatus, generateReply} from "../src/services/aiProvider.js";

test("AI provider defaults to safe unconfigured mode",()=>{
  const status=aiStatus();
  assert.equal(status.provider,"none");
  assert.equal(status.configured,false);
});

test("unconfigured provider returns fallback signal",async()=>{
  const result=await generateReply({message:"hello",mode:"companion",language:"en",understanding:{intent:"casual_conversation",tone:"neutral",goal:"answer",urgency:"low",responseStyle:"conversational"},context:[]});
  assert.equal(result,null);
});
