import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
test("v3 conversation and account routes exist",()=>{
  assert.ok(fs.existsSync(path.join(root,"src/routes/conversations.js")));
  assert.ok(fs.existsSync(path.join(root,"src/routes/account.js")));
  assert.ok(fs.readFileSync(path.join(root,"src/store/db.js"),"utf8").includes("CREATE TABLE IF NOT EXISTS conversations"));
});
test("v3 privacy controls are separate from long-term memory",()=>{
  const route=fs.readFileSync(path.join(root,"src/routes/account.js"),"utf8");
  assert.match(route,/\/export/); assert.match(route,/DELETE FROM users/);
});
test("v3 companion persists completed responses",()=>{
  const stream=fs.readFileSync(path.join(root,"src/routes/companionStream.js"),"utf8");
  const normal=fs.readFileSync(path.join(root,"src/routes/companion.js"),"utf8");
  assert.match(stream,/saveConversationMessage/); assert.match(normal,/saveConversationMessage/);
});
