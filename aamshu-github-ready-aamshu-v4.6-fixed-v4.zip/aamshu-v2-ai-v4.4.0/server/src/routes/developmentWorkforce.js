import express from 'express';
import { plan, nextRunnable, complete, fail, AGENTS } from '../agents/workforce.js';
import { runReadyWorkers } from '../services/workforceRunner.js';
import { workerProviderStatus } from '../services/workerProvider.js';
import { normalizeArtifacts, summarizeArtifacts, validatePatchProposals } from '../services/workforceArtifacts.js';
import { createCandidateWorkspace } from '../services/workspaceEngine.js';

export const developmentWorkforceRouter = express.Router();
const jobs = new Map();

developmentWorkforceRouter.post('/plan', (req, res) => {
  const task = String(req.body?.task || '').trim();
  if (!task || task.length > 2000) return res.status(400).json({ error: 'task is required and must be <= 2000 characters' });
  const work = plan(task); work.ownerId = req.user.id; work.artifacts = []; jobs.set(work.id, work);
  res.status(201).json({ work, agents: AGENTS, workerProvider: workerProviderStatus() });
});

developmentWorkforceRouter.get('/:id', (req, res) => {
  const work = jobs.get(req.params.id);
  if (!work || work.ownerId !== req.user.id) return res.status(404).json({ error: 'work plan not found' });
  res.json({ work, next: nextRunnable(work) });
});

developmentWorkforceRouter.post('/:id/jobs/:jobId/complete', (req, res) => {
  const work = jobs.get(req.params.id);
  if (!work || work.ownerId !== req.user.id) return res.status(404).json({ error: 'work plan not found' });
  const job = work.jobs.find(j => j.id === req.params.jobId);
  if (!job) return res.status(404).json({ error: 'job not found' });
  complete(work, job.id, req.body?.result || {});
  res.json({ work, next: nextRunnable(work) });
});

developmentWorkforceRouter.post('/:id/jobs/:jobId/fail', (req, res) => {
  const work = jobs.get(req.params.id);
  if (!work || work.ownerId !== req.user.id) return res.status(404).json({ error: 'work plan not found' });
  try { fail(work, req.params.jobId, req.body?.error); res.json({ work, next: nextRunnable(work) }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});





developmentWorkforceRouter.post('/:id/candidate', async (req, res) => {
  const work = jobs.get(req.params.id);
  if (!work || work.ownerId !== req.user.id) return res.status(404).json({ error: 'work plan not found' });
  const artifacts = normalizeArtifacts(req.body?.artifacts || work.artifacts || []);
  const proposals = [];
  for (const job of work.jobs.filter(j => j.status === 'completed')) {
    proposals.push(...validatePatchProposals(job.result || {}));
  }
  try {
    const candidate = await createCandidateWorkspace(artifacts, proposals);
    if (!candidate.applied) return res.status(409).json({ error: 'patch_conflict', conflicts: candidate.conflicts });
    res.json({
      status: 'candidate_ready',
      changes: candidate.changes,
      artifacts: candidate.artifacts.map(a => ({ path: a.path, hash: a.hash, chars: a.content.length })),
      note: 'Candidate workspace is isolated and ephemeral; no server source files were modified.'
    });
  } catch (e) {
    res.status(500).json({ error: 'candidate_workspace_failed' });
  }
});

developmentWorkforceRouter.post('/:id/run', async (req, res) => {
  const work = jobs.get(req.params.id);
  if (!work || work.ownerId !== req.user.id) return res.status(404).json({ error: 'work plan not found' });
  try {
    const artifacts = normalizeArtifacts(req.body?.artifacts);
    work.artifacts = artifacts;
    const result = await runReadyWorkers(work, { context: Array.isArray(req.body?.context) ? req.body.context.slice(-12) : [], artifacts });
    res.json({ ...result, next: nextRunnable(work), artifacts: summarizeArtifacts(work.artifacts), workerProvider: workerProviderStatus() });
  } catch (e) {
    res.status(500).json({ error: 'workforce_run_failed' });
  }
});
