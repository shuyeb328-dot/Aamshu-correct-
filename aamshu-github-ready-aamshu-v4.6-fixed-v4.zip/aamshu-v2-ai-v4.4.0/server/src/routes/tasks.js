import { Router } from "express";
import { nanoid } from "nanoid";
import { db } from "../store/db.js";
import { requireAuth } from "../services/auth.js";
import { runSandbox } from "../sandbox/runner.js";

export const tasksRouter = Router();
tasksRouter.use(requireAuth);

function ownsProject(projectId,userId) {
  return db.prepare("SELECT id FROM projects WHERE id=? AND user_id=?").get(projectId,userId);
}

tasksRouter.post("/", async (req,res) => {
  const projectId = String(req.body?.projectId || "");
  if (!ownsProject(projectId, req.user.sub)) return res.status(404).json({error:"project_not_found"});

  const prompt = String(req.body?.prompt || "").trim();
  const tests = String(req.body?.tests || "").slice(0,20000);
  const category = String(req.body?.category || "coding").trim().toLowerCase();
  const allowedCategories = new Set(["coding","debugging","refactoring","testing"]);
  if (!prompt || prompt.length > 20000) return res.status(400).json({error:"invalid_prompt"});
  if (!allowedCategories.has(category)) return res.status(400).json({error:"invalid_category"});

  const task = {
    id:nanoid(), project_id:projectId, user_id:req.user.sub, category, prompt,
    tests, status:"running", created_at:new Date().toISOString()
  };
  db.prepare("INSERT INTO tasks (id,project_id,user_id,category,prompt,tests,status,created_at) VALUES (@id,@project_id,@user_id,@category,@prompt,@tests,@status,@created_at)").run(task);

  const run = {
    id:nanoid(), task_id:task.id, project_id:projectId, attempt:1, status:"queued",
    diagnostics:"", output:"", duration_ms:0, created_at:new Date().toISOString(), finished_at:null
  };
  db.prepare("INSERT INTO runs (id,task_id,project_id,attempt,status,diagnostics,output,duration_ms,created_at,finished_at) VALUES (@id,@task_id,@project_id,@attempt,@status,@diagnostics,@output,@duration_ms,@created_at,@finished_at)").run(run);

  // v2 orchestration hook. The default runner is safe/disabled.
  const result = await runSandbox({command:"echo Aamshu sandbox adapter ready"});
  db.prepare("UPDATE runs SET status=?,diagnostics=?,output=?,duration_ms=?,finished_at=? WHERE id=?")
    .run(result.status,result.diagnostics,result.output,result.durationMs,new Date().toISOString(),run.id);
  db.prepare("UPDATE tasks SET status=? WHERE id=?").run(result.status === "passed" ? "completed" : result.status, task.id);

  res.status(201).json({
    task,
    run: db.prepare("SELECT * FROM runs WHERE id=?").get(run.id),
    next: result.status === "sandbox_required" ? "configure_runner" : "inspect_result"
  });
});

tasksRouter.get("/project/:projectId", (req,res) => {
  if (!ownsProject(req.params.projectId, req.user.sub)) return res.status(404).json({error:"project_not_found"});
  const rows = db.prepare(`
    SELECT t.*, r.id AS run_id, r.status AS run_status, r.diagnostics, r.output, r.duration_ms
    FROM tasks t LEFT JOIN runs r ON r.task_id=t.id
    WHERE t.project_id=? ORDER BY t.created_at DESC LIMIT 100
  `).all(req.params.projectId);
  res.json(rows);
});
