import { Router } from "express";
import { requireAuth } from "../services/auth.js";
import { clearConversation, listConversation } from "../services/conversations.js";
export const conversationsRouter = Router();
conversationsRouter.use(requireAuth);
conversationsRouter.get("/", (req,res)=>res.json({messages:listConversation(req.user.sub, req.query.limit)}));
conversationsRouter.delete("/", (req,res)=>res.json({ok:true,deleted:clearConversation(req.user.sub)}));
