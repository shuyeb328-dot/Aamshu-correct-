import {Router} from "express";
import {requireAuth} from "../services/auth.js";
import {getCompanionMemories,deleteCompanionMemory,clearCompanionMemories} from "../services/companionMemory.js";

export const companionMemoriesRouter=Router();
companionMemoriesRouter.use(requireAuth);

companionMemoriesRouter.get("/",(req,res)=>{
  res.json({memories:getCompanionMemories(req.user.sub)});
});

companionMemoriesRouter.delete("/:id",(req,res)=>{
  if(!deleteCompanionMemory(req.user.sub,String(req.params.id))) return res.status(404).json({error:"memory_not_found"});
  res.json({ok:true});
});

companionMemoriesRouter.delete("/",(req,res)=>{
  const deleted=clearCompanionMemories(req.user.sub);
  res.json({ok:true,deleted});
});
