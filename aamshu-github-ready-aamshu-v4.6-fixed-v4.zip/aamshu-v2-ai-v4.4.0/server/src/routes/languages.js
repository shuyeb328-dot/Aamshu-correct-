import { Router } from "express";
import { languageCatalog, isoCatalog, findLanguage } from "../services/languages.js";

export const languagesRouter = Router();

languagesRouter.get("/", (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
  const offset = Math.max(Number(req.query.offset) || 0, 0);
  res.json(languageCatalog({ q: req.query.q, limit, offset }));
});

languagesRouter.get("/iso639-3", (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
  const offset = Math.max(Number(req.query.offset) || 0, 0);
  res.json(isoCatalog({ q: req.query.q, limit, offset }));
});

languagesRouter.get("/:id", (req, res) => {
  const item = findLanguage(req.params.id);
  if (!item) return res.status(404).json({ error: "language_not_found" });
  res.json(item);
});
