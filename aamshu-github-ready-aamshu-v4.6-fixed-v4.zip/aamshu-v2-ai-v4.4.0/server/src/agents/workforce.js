import crypto from 'node:crypto';

export const AGENTS = {
  architect: { title: 'Architect', skills: ['architecture', 'decomposition', 'interfaces'] },
  android: { title: 'Android Engineer', skills: ['android', 'native', 'permissions'] },
  backend: { title: 'Backend Engineer', skills: ['api', 'database', 'auth'] },
  ai: { title: 'AI Engineer', skills: ['models', 'prompts', 'streaming'] },
  voice: { title: 'Voice Engineer', skills: ['stt', 'tts', 'audio'] },
  security: { title: 'Security Engineer', skills: ['threat-model', 'hardening', 'abuse-prevention'] },
  ui: { title: 'UI Engineer', skills: ['react-native', 'ux', 'accessibility'] },
  qa: { title: 'QA Engineer', skills: ['tests', 'regression', 'validation'] },
  reviewer: { title: 'Reviewer', skills: ['review', 'risk', 'release-gate'] }
};

function id() { return crypto.randomUUID(); }

export function classify(task) {
  const t = String(task || '').toLowerCase();
  const tags = [];
  if (/android|native|notification|foreground|permission|apk/.test(t)) tags.push('android');
  if (/api|server|database|auth|backend|endpoint/.test(t)) tags.push('backend');
  if (/ai|model|prompt|agent|stream/.test(t)) tags.push('ai');
  if (/voice|microphone|speech|tts|stt|wake/.test(t)) tags.push('voice');
  if (/security|secure|attack|hack|credential|privacy/.test(t)) tags.push('security');
  if (/ui|screen|button|design|ux|layout/.test(t)) tags.push('ui');
  if (/test|bug|crash|regression|validate/.test(t)) tags.push('qa');
  return [...new Set(tags)];
}

export function plan(task) {
  const tags = classify(task);
  const specialist = tags.length ? tags : ['architect', 'backend', 'ai', 'qa'];
  const selected = specialist.map(k => k === 'architect' ? k : k).filter(k => AGENTS[k]);
  if (!selected.includes('architect')) selected.unshift('architect');
  if (!selected.includes('security')) selected.push('security');
  if (!selected.includes('qa')) selected.push('qa');
  const jobs = selected.map((agent, i) => ({
    id: id(), agent, status: 'queued', dependsOn: i === 0 ? [] : [], task,
    deliverables: ['findings', 'proposed_changes', 'tests'], attempts: 0
  }));
  for (const j of jobs.slice(1)) j.dependsOn = [jobs[0].id];
  jobs.push({ id: id(), agent: 'reviewer', status: 'blocked', dependsOn: jobs.map(j => j.id), task,
    deliverables: ['review', 'release_gate'], attempts: 0 });
  return { id: id(), task, status: 'planned', createdAt: new Date().toISOString(), jobs };
}

export function nextRunnable(work) {
  return work.jobs.filter(j => j.status === 'queued' && j.dependsOn.every(d => work.jobs.find(x => x.id === d)?.status === 'completed'));
}

export function complete(work, jobId, result) {
  const job = work.jobs.find(j => j.id === jobId);
  if (!job) throw new Error('Unknown job');
  job.status = 'completed'; job.completedAt = new Date().toISOString(); job.result = result || {};
  const reviewer = work.jobs.find(j => j.agent === 'reviewer');
  if (reviewer && reviewer.status === 'blocked' && reviewer.dependsOn.every(d => work.jobs.find(x => x.id === d)?.status === 'completed')) reviewer.status = 'queued';
  if (work.jobs.every(j => j.status === 'completed')) work.status = 'completed';
  return work;
}

export function fail(work, jobId, error) {
  const job = work.jobs.find(j => j.id === jobId);
  if (!job) throw new Error('Unknown job');
  job.attempts += 1; job.error = String(error || 'worker failed');
  job.status = job.attempts < 3 ? 'queued' : 'failed';
  work.status = 'running';
  return work;
}

