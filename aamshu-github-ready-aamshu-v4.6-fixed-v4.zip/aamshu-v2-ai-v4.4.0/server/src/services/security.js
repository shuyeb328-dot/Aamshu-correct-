import crypto from 'node:crypto';

const MAX_EVENT_BODY = 700;
const blockedPath = /(?:\.\.(?:\/|\\)|%2e%2e|%252e|\0)/i;
const suspiciousInput = /(?:<\s*script\b|javascript\s*:|\b(?:union\s+select|drop\s+table|insert\s+into|delete\s+from)\b|(?:;|&&|\|\|)\s*(?:curl|wget|nc|bash|sh|powershell)\b)/i;

export function requestId(req, _res, next) {
  const incoming = String(req.headers['x-request-id'] || '').trim();
  req.requestId = /^[A-Za-z0-9._-]{8,80}$/.test(incoming) ? incoming : crypto.randomUUID();
  next();
}

export function securityHeaders(app) {
  app.use((req, res, next) => {
    res.setHeader('X-Request-ID', req.requestId || crypto.randomUUID());
    res.setHeader('Cache-Control', 'no-store');
    next();
  });
}

export function securityGate(req, res, next) {
  const target = `${req.originalUrl || ''}`;
  if (target.length > 4096 || blockedPath.test(target)) {
    safeAudit('blocked_request_path', { requestId: req.requestId, ip: req.ip, path: target.slice(0, 500) });
    return res.status(400).json({ error: 'invalid_request', requestId: req.requestId });
  }
  next();
}

export function safeAudit(event, data = {}) {
  const clean = { ...data };
  for (const key of ['authorization', 'token', 'password', 'password_hash', 'apiKey', 'api_key']) {
    if (key in clean) clean[key] = '[REDACTED]';
  }
  try {
    console.warn(JSON.stringify({
      type: 'security_audit',
      event,
      at: new Date().toISOString(),
      ...Object.fromEntries(Object.entries(clean).map(([k, v]) => [k, String(v).slice(0, MAX_EVENT_BODY)]))
    }));
  } catch {}
}
