import { nanoid } from "nanoid";
import { db } from "../store/db.js";

const MAX_CONTENT = 12000;
export function saveConversationMessage(userId, role, content, language="en") {
  if (!userId || !["human","aamshu"].includes(role)) return null;
  const value = String(content || "").trim().slice(0, MAX_CONTENT);
  if (!value) return null;
  const id = nanoid(18);
  db.prepare("INSERT INTO conversations (id,user_id,role,content,language,created_at) VALUES (?,?,?,?,?,?)")
    .run(id, userId, role, value, String(language || "en").slice(0,35), new Date().toISOString());
  return { id, role, content:value, language:String(language || "en").slice(0,35) };
}
export function listConversation(userId, limit=50) {
  const n = Math.max(1, Math.min(Number(limit)||50, 200));
  return db.prepare("SELECT id,role,content,language,created_at FROM conversations WHERE user_id = ? ORDER BY created_at DESC LIMIT ?")
    .all(userId,n).reverse();
}
export function clearConversation(userId) {
  return db.prepare("DELETE FROM conversations WHERE user_id = ?").run(userId).changes;
}
