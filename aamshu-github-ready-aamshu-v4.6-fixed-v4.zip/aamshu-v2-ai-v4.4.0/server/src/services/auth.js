import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { nanoid } from "nanoid";
import { db } from "../store/db.js";
import { safeAudit } from "./security.js";

const secret = process.env.JWT_SECRET;
const issuer = process.env.JWT_ISSUER || "aamshu-v2";
if (!secret || secret.length < 32) {
  if (process.env.NODE_ENV === "production") {
    throw new Error("JWT_SECRET must be at least 32 characters in production");
  }
}

export async function createUser(email, password) {
  const normalized = String(email || "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized) || password.length < 10 || password.length > 200) throw new Error("Invalid credentials");
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(normalized);
  if (existing) throw new Error("Email already registered");
  const id = nanoid();
  const hash = await bcrypt.hash(password, 12);
  db.prepare("INSERT INTO users (id,email,password_hash,created_at) VALUES (?,?,?,?)")
    .run(id, normalized, hash, new Date().toISOString());
  return { id, email: normalized };
}

export async function verifyUser(email, password) {
  const normalized = String(email || "").trim().toLowerCase();
  if (!normalized || !password || password.length > 200) return null;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(normalized);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return null;
  return { id: user.id, email: user.email };
}

export function signSession(user) {
  const jti = nanoid(24);
  const token = jwt.sign({ sub: user.id, email: user.email, jti }, secret || "dev-only-secret", { expiresIn: "7d", issuer, algorithm: "HS256" });
  db.prepare("INSERT INTO sessions (id,user_id,created_at,expires_at) VALUES (?,?,?,?)").run(jti, user.id, new Date().toISOString(), new Date(Date.now()+7*24*60*60*1000).toISOString());
  return token;
}

export function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) return res.status(401).json({ error: "authentication_required" });
    const token = header.slice(7);
    req.user = jwt.verify(token, secret || "dev-only-secret", { algorithms: ["HS256"], issuer });
    if (!req.user.jti || !db.prepare("SELECT id FROM sessions WHERE id = ? AND user_id = ? AND revoked_at IS NULL AND expires_at > ?").get(req.user.jti, req.user.sub, new Date().toISOString())) {
      return res.status(401).json({ error: "session_revoked" });
    }
    next();
  } catch {
    return res.status(401).json({ error: "invalid_session" });
  }
}
