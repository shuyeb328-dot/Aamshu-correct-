import { URL } from "node:url";

const MAX_TEXT = 300;

function clean(value) {
  return String(value || "").trim().slice(0, MAX_TEXT);
}

function safeHttpUrl(value) {
  try {
    const u = new URL(value);
    if (!['http:', 'https:'].includes(u.protocol)) return null;
    return u.toString();
  } catch { return null; }
}

function findUrl(text) {
  const m = text.match(/https?:\/\/[^\s]+/i);
  return m ? safeHttpUrl(m[0].replace(/[),.!?]+$/, '')) : null;
}

function phone(text) {
  const m = text.match(/(?:call|dial)\s+([+\d][\d\s().-]{5,24})$/i);
  return m ? m[1].replace(/[^+\d]/g, '').slice(0, 20) : null;
}

function sms(text) {
  const m = text.match(/(?:text|sms|message)\s+([+\d][\d\s().-]{5,24})\s*(?:saying|with message)\s+(.+)$/i);
  return m ? { phone: m[1].replace(/[^+\d]/g, '').slice(0, 20), body: clean(m[2]) } : null;
}

export function planAssistantAction(input) {
  const text = clean(input);
  const lower = text.toLowerCase();
  if (!text) return { type: 'none', requiresConfirmation: false, reply: 'I’m ready. Tell me what you want me to do.' };

  const number = phone(text);
  if (number) return {
    type: 'phone.call', target: number, requiresConfirmation: true,
    reply: `I can open the phone app with ${number} ready to call. You confirm the call on your device.`
  };

  const message = sms(text);
  if (message) return {
    type: 'sms.compose', target: message.phone, body: message.body, requiresConfirmation: true,
    reply: `I can open a message to ${message.phone} with your text ready. You confirm sending it.`
  };

  const url = findUrl(text);
  if (url) return {
    type: 'web.open', target: url, requiresConfirmation: true,
    reply: `I can open that website in your browser.`
  };

  const map = lower.match(/(?:navigate|directions|take me|route)\s+(?:to\s+)?(.+)/i);
  if (map) {
    const destination = clean(map[1]);
    return { type: 'maps.search', target: destination, requiresConfirmation: true, reply: `I can open Maps for ${destination}.` };
  }

  if (/^(what can you do|help|commands)$/i.test(text)) return {
    type: 'none', requiresConfirmation: false,
    reply: 'I can talk, remember explicit preferences, help with coding, open a website, prepare a phone call or message, and open Maps. Device actions always require your confirmation.'
  };

  return { type: 'none', requiresConfirmation: false, reply: 'I understand the request, but I do not have a safe device action for it yet. I can still help you through conversation.' };
}
