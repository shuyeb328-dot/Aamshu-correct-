import dns from 'node:dns/promises';
import net from 'node:net';

function privateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a,b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a === 0;
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    return x === '::1' || x === '::' || x.startsWith('fc') || x.startsWith('fd') || x.startsWith('fe80:');
  }
  return false;
}

export async function validateProviderUrl(value) {
  const u = new URL(value);
  if (u.protocol !== 'https:' && !(process.env.NODE_ENV !== 'production' && u.protocol === 'http:')) throw new Error('ai_provider_https_required');
  if (u.username || u.password) throw new Error('ai_provider_credentials_in_url');
  const hostname = u.hostname.replace(/^\[|\]$/g, '');
  if (privateIp(hostname)) throw new Error('ai_provider_private_address_blocked');
  if (net.isIP(hostname)) return true;
  const records = await dns.lookup(hostname, { all: true });
  if (!records.length || records.some(x => privateIp(x.address))) throw new Error('ai_provider_private_address_blocked');
  return true;
}
