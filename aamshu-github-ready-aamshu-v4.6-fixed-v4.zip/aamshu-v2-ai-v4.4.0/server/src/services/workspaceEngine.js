import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';

const MAX_PATCHES = 40;
const MAX_FILE = 12000;

function safeRelative(p) {
  const v = String(p || '').trim().replace(/\\/g, '/');
  if (!v || v.startsWith('/') || v.includes('..') || /\0/.test(v)) return null;
  if (!/^[A-Za-z0-9._\-/]+$/.test(v)) return null;
  return v;
}

export function sha256(content = '') {
  return crypto.createHash('sha256').update(String(content)).digest('hex');
}

export function validatePatchSet(patches = []) {
  if (!Array.isArray(patches)) return [];
  return patches.slice(0, MAX_PATCHES).map(p => ({
    operation: ['create', 'update', 'delete'].includes(p?.operation) ? p.operation : 'update',
    path: safeRelative(p?.path),
    content: String(p?.content || '').slice(0, MAX_FILE),
    base_hash: p?.base_hash ? String(p.base_hash) : null,
    rationale: String(p?.rationale || '').slice(0, 800)
  })).filter(p => p.path);
}

export function detectConflicts(patches = [], snapshot = {}) {
  const normalized = validatePatchSet(patches);
  const conflicts = [];
  const seen = new Map();
  for (const p of normalized) {
    if (seen.has(p.path)) conflicts.push({ path: p.path, reason: 'duplicate_patch_target' });
    seen.set(p.path, p);
    const current = snapshot[p.path];
    const currentHash = current?.hash || (current?.content != null ? sha256(current.content) : null);
    if (p.base_hash && currentHash && p.base_hash !== currentHash) conflicts.push({ path: p.path, reason: 'base_hash_mismatch', expected: p.base_hash, actual: currentHash });
    if (p.operation === 'create' && currentHash) conflicts.push({ path: p.path, reason: 'create_target_exists' });
    if (p.operation === 'delete' && !currentHash) conflicts.push({ path: p.path, reason: 'delete_target_missing' });
  }
  return { conflicts, clean: conflicts.length === 0 };
}

export async function readSnapshot(root, paths = []) {
  const snapshot = {};
  for (const raw of paths) {
    const rel = safeRelative(raw);
    if (!rel) continue;
    const abs = path.resolve(root, rel);
    if (!abs.startsWith(path.resolve(root) + path.sep)) continue;
    try {
      const content = await fs.readFile(abs, 'utf8');
      snapshot[rel] = { content, hash: sha256(content) };
    } catch (e) {
      if (e.code !== 'ENOENT') throw e;
      snapshot[rel] = { content: null, hash: null };
    }
  }
  return snapshot;
}

export async function applyPatchSet(root, patches = [], snapshot = {}) {
  const normalized = validatePatchSet(patches);
  const check = detectConflicts(normalized, snapshot);
  if (!check.clean) return { applied: false, conflicts: check.conflicts, changes: [] };
  const changes = [];
  for (const p of normalized) {
    const abs = path.resolve(root, p.path);
    if (!abs.startsWith(path.resolve(root) + path.sep)) throw new Error('unsafe patch path');
    if (p.operation === 'delete') {
      await fs.rm(abs, { force: true });
    } else {
      await fs.mkdir(path.dirname(abs), { recursive: true });
      await fs.writeFile(abs, p.content, 'utf8');
    }
    changes.push({ path: p.path, operation: p.operation, hash: p.operation === 'delete' ? null : sha256(p.content) });
  }
  return { applied: true, conflicts: [], changes };
}

export async function createCandidateWorkspace(artifacts = [], patches = []) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'aamshu-candidate-'));
  const files = {};
  for (const item of artifacts) {
    const rel = safeRelative(item?.path);
    if (!rel) continue;
    const content = String(item?.content || '').slice(0, MAX_FILE);
    const abs = path.resolve(root, rel);
    await fs.mkdir(path.dirname(abs), { recursive: true });
    await fs.writeFile(abs, content, 'utf8');
    files[rel] = { content, hash: sha256(content) };
  }
  const targets = validatePatchSet(patches).map(p => p.path);
  const snapshot = await readSnapshot(root, [...new Set([...Object.keys(files), ...targets])]);
  const result = await applyPatchSet(root, patches, snapshot);
  if (!result.applied) return { ...result, root, artifacts: [] };
  const out = [];
  for (const rel of Object.keys(snapshot).concat(result.changes.map(c => c.path))) {
    if (out.some(x => x.path === rel)) continue;
    const safe = safeRelative(rel);
    if (!safe) continue;
    const abs = path.resolve(root, safe);
    try {
      const content = await fs.readFile(abs, 'utf8');
      out.push({ path: safe, content, hash: sha256(content) });
    } catch (e) {
      if (e.code !== 'ENOENT') throw e;
    }
  }
  return { ...result, root, artifacts: out };
}
