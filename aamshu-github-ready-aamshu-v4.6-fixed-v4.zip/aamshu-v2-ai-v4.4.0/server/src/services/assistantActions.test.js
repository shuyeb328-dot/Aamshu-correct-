import test from 'node:test';
import assert from 'node:assert/strict';
import { planAssistantAction } from './assistantActions.js';

test('plans call without executing it', () => {
  const a = planAssistantAction('call +91 98765 43210');
  assert.equal(a.type, 'phone.call');
  assert.equal(a.requiresConfirmation, true);
  assert.equal(a.target, '+919876543210');
});

test('plans SMS composition with bounded content', () => {
  const a = planAssistantAction('message +91 9876543210 saying Hello there');
  assert.equal(a.type, 'sms.compose');
  assert.equal(a.requiresConfirmation, true);
  assert.equal(a.body, 'Hello there');
});

test('rejects non-http URL schemes', () => {
  const a = planAssistantAction('open javascript:alert(1)');
  assert.equal(a.type, 'none');
});

test('does not turn arbitrary commands into device actions', () => {
  const a = planAssistantAction('run shell command and delete files');
  assert.equal(a.type, 'none');
});
