const INTENTS = [
  ["troubleshooting", /\b(error|bug|broken|fail\w*|crash\w*|issue|problem|fix|debug)\b/i],
  ["build_or_create", /\b(build|create|make|develop|design|add|implement|upgrade)\b/i],
  ["decision_support", /\b(should i|which|choose|choice|decide|decision|worth|better)\b/i],
  ["explanation", /\b(why|how|what does|explain|meaning|understand|teach)\b/i],
  ["planning", /\b(plan|roadmap|steps|next step|schedule|prepare)\b/i],
  ["emotional_support", /\b(sad|lonely|upset|frustrated|angry|stressed|overwhelmed|worried|anxious|scared|hurt|tired)\b/i],
  ["casual_conversation", /\b(hello|hi|hey|good morning|good night|talk|chat)\b/i]
];
const TONE = [
  ["frustrated", /\b(frustrated|annoyed|fed up|angry|damn|ugh|not working)\b/i],
  ["worried", /\b(worried|anxious|scared|nervous|concerned|panic)\b/i],
  ["sad", /\b(sad|lonely|hurt|cry|depressed)\b/i],
  ["excited", /\b(excited|awesome|amazing|great|love it|can't wait)\b/i],
  ["neutral", /.*/]
];
const URGENCY = [
  ["high", /\b(now|urgent|asap|immediately|emergency|right away)\b/i],
  ["medium", /\b(today|soon|quick|quickly)\b/i],
  ["low", /.*/]
];
const GOALS = [
  ["answer", /\b(what|why|how|explain|tell me)\b/i],
  ["action", /\b(do|build|create|fix|make|add|change|implement)\b/i],
  ["reassurance", /\b(okay|alright|am i|is this|worried|scared)\b/i],
  ["listening", /\b(just listen|talk|vent|need to talk)\b/i]
];

function firstMatch(list,text,fallback){ return list.find(([,re])=>re.test(text))?.[0] || fallback; }
function normalizeContext(context){
  if(!Array.isArray(context)) return [];
  return context.slice(-8).map(x=>({role:x?.role==="aamshu"?"aamshu":"human",text:String(x?.text||"").slice(0,800)})).filter(x=>x.text);
}
export function understand(message, context=[]){
  const text=String(message||"").trim();
  const ctx=normalizeContext(context);
  const combined=[...ctx.filter(x=>x.role==="human").map(x=>x.text),text].join(" ");
  const intent=firstMatch(INTENTS,combined,"general_help");
  const tone=firstMatch(TONE,text,"neutral");
  const urgency=firstMatch(URGENCY,text,"low");
  const goal=firstMatch(GOALS,text,"answer");
  const asksQuestion=/\?|\b(why|how|what|when|where|who|which)\b/i.test(text);
  const needsClarification=text.length<8 || /\b(it|this|that|there|something)\b/i.test(text) && !ctx.length;
  const responseStyle = tone === "frustrated" || tone === "worried" || tone === "sad"
    ? "warm_and_concrete"
    : goal === "action" ? "direct_and_actionable"
    : asksQuestion ? "clear_and_explanatory" : "conversational";
  return {
    intent, tone, urgency, goal, responseStyle,
    needsClarification,
    contextTurns:ctx.length,
    confidence: text.length >= 20 ? "medium" : "low"
  };
}
