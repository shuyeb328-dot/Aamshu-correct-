import { spawn } from "node:child_process";

const mode = process.env.SANDBOX_MODE || "disabled";
const image = process.env.SANDBOX_IMAGE || "aamshu-runner:latest";
const timeoutMs = Number(process.env.SANDBOX_TIMEOUT_MS || 15000);
const memoryMb = Number(process.env.SANDBOX_MEMORY_MB || 256);
const cpus = Number(process.env.SANDBOX_CPUS || 1);
const network = process.env.SANDBOX_NETWORK || "none";

/**
 * The disabled adapter is the safe default.
 * Production should use a dedicated runner service rather than exposing
 * the Docker socket directly to the API process.
 */
export async function runSandbox({ files = [], command = "echo sandbox-ready" } = {}) {
  if (mode !== "docker") {
    return {
      status: "sandbox_required",
      output: "",
      diagnostics: "Execution is disabled. Configure a dedicated isolated runner before enabling code execution.",
      durationMs: 0
    };
  }

  // Defense-in-depth flags. The image must itself be non-root and minimal.
  const args = [
    "run", "--rm",
    "--network", network,
    "--memory", `${memoryMb}m`,
    "--cpus", String(cpus),
    "--pids-limit", "64",
    "--read-only",
    "--cap-drop", "ALL",
    "--security-opt", "no-new-privileges",
    image,
    "sh", "-lc", command
  ];

  return new Promise((resolve) => {
    const started = Date.now();
    const child = spawn("docker", args, { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    let done = false;

    const finish = (result) => {
      if (done) return;
      done = true;
      resolve({ ...result, durationMs: Date.now() - started });
    };

    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      finish({
        status: "timeout",
        output: stdout,
        diagnostics: "Sandbox execution exceeded the configured timeout."
      });
    }, timeoutMs);

    child.stdout.on("data", (b) => { stdout += b.toString().slice(0, 100000); });
    child.stderr.on("data", (b) => { stderr += b.toString().slice(0, 100000); });

    child.on("error", (err) => {
      clearTimeout(timer);
      finish({ status: "runner_error", output: stdout, diagnostics: err.message });
    });

    child.on("close", (code) => {
      clearTimeout(timer);
      finish({
        status: code === 0 ? "passed" : "failed",
        output: stdout,
        diagnostics: stderr || (code === 0 ? "Tests completed." : `Process exited with code ${code}.`)
      });
    });
  });
}
