# Aamshu v2 — Autonomous Coding Platform

Aamshu v2 is a production-oriented full-stack coding-engine platform:

- Mobile: Expo / React Native
- Web: React + Vite
- API: Node.js + Express
- Persistence: SQLite starter store
- Authentication: password hashing + bearer sessions
- Execution: isolated sandbox adapter with Docker support
- Memory: project-scoped episodic memory
- Runs: queued execution model with diagnostics and retry support
- Android: EAS APK/AAB configuration

## Architecture

```text
Mobile / Web
     |
     v
  Express API
     |
     +--> Auth / Projects / Tasks / Runs / Memory
     |
     +--> Sandbox Runner
              |
              +--> Docker (recommended)
              |
              +--> Safe "disabled" adapter (default)
```

The server never executes arbitrary code directly in the Node.js process.
The Docker sandbox is deliberately opt-in and must be hardened before public deployment.

## Quick start

### API

```bash
cd server
cp .env.example .env
npm install
npm run dev
```

### Web

```bash
cd web
npm install
npm run dev
```

### Mobile

```bash
cd mobile
npm install
npx expo start
```

## Account setup

Create an account from the mobile app. The web console currently uses an existing account session; use the API/mobile registration flow for first-time account creation. No default production credentials are provisioned.

## Android

Preview APK:

```bash
cd mobile
npm install
npx eas login
npx eas build:configure
npm run build:apk
```

Play Store AAB:

```bash
npm run build:play
```

## Security

Do not expose the Docker socket to an untrusted public API.
Use a dedicated runner host, rootless Docker/Podman, resource limits, restricted networking,
ephemeral workspaces, non-root containers, and strong authentication.

A mobile API key is not a secret once shipped inside an APK. v2 uses user sessions instead.

See `docs/SECURITY.md` and `docs/PRODUCTION.md`.


## Global language system

Aamshu v2.1 now bundles a global language catalog: CLDR-derived locale metadata plus ISO 639-3 language records. The mobile app includes the catalog offline, supports language search and locale selection for the voice companion, and the API exposes `/api/languages` and `/api/languages/:id`.

The bundle currently contains **1,082 locale records, 312 CLDR-derived language profiles, and 7,910 ISO 639-3 records**. Locale coverage is device/provider dependent for speech recognition and TTS; the catalog does not imply that Android supports voice synthesis for every language.

The current Unicode CLDR 49 line is in beta, so the bundled snapshot is deliberately reproducible and includes a refresh script rather than pretending arbitrary internet data is authoritative. Unicode describes CLDR as the trusted repository for locale data and publishes stable releases separately from development/beta data.


## v2.6 streaming companion

The companion now supports authenticated SSE streaming from an OpenAI-compatible backend. The Android client renders incremental text while the server keeps AI credentials private. See `docs/STREAMING-COMPANION.md`.
