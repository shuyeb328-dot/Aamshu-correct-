# Language data refresh

Aamshu bundles two standards-oriented datasets:

1. **CLDR-derived locale data** through the installed Babel snapshot: localized names, native names, likely script/region, direction, plural and ordinal categories, and locale variants.
2. **ISO 639-3** language identifiers and names through pycountry.

The official Unicode CLDR 49 release is currently in beta; stable CLDR releases should be preferred for production refreshes. The generator intentionally keeps the data build reproducible rather than scraping arbitrary websites.

```bash
python -m pip install Babel==2.18.0 pycountry==24.6.1
python scripts/build-language-data.py
```

The generated JSON is copied into both the mobile offline bundle and server API.
