# Production deployment

1. Put the API behind HTTPS.
2. Use a managed PostgreSQL database for production scale instead of the starter SQLite store.
3. Move sandbox execution to a dedicated isolated runner host.
4. Add queueing (Redis/SQS/etc.) so execution does not block HTTP requests.
5. Add observability and audit logs.
6. Configure backups and database migrations.
7. Replace the demo account and disable development bootstrap.
8. Use short-lived user tokens / refresh tokens with revocation.
9. Host the privacy policy at a public HTTPS URL.
10. Complete Google Play Data Safety and content rating forms.
