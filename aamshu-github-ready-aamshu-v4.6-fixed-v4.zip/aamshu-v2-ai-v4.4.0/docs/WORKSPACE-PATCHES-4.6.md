# Aamshu v4.6 — Isolated Workspace & Patch Gate

Workers can propose bounded file changes. A patch is applied only when its target path is safe and its optional base hash still matches the workspace snapshot. Conflicting changes are rejected rather than silently overwritten.

The workspace engine is deliberately separate from the host Android build environment. Production deployments should execute project tests/builds in a dedicated sandbox with CPU, memory, process, filesystem, and network limits.

Flow: worker proposal → snapshot → conflict check → patch apply → tests → reviewer → release gate.
