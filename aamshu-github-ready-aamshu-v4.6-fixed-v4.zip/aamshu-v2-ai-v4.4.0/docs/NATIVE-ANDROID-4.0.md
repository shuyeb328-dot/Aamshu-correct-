# Aamshu 4.0 Native Android Assistant

Aamshu 4.0 adds a native Android foreground-service foundation and a React Native bridge.

## Lifecycle
- `AamshuAssistant.startAssistant()` starts the visible foreground service.
- `AamshuAssistant.stopAssistant()` stops it.
- `AamshuAssistant.isAssistantActive()` reports the process-local state.

The service is `START_NOT_STICKY` and `stopWithTask=true`; it does not silently restart after termination.

## Voice/privacy boundary
The service is a lifecycle foundation, not a hidden recorder. Microphone access remains user-controlled and Android-visible. Future wake-word work must add an explicit opt-in state, battery policy, and Android-version-specific testing.

## Capability boundary
The native module exposes only registered assistant capabilities. AI planning is separate from native execution and consequential actions remain confirmation-gated.

## Build requirement
This source package requires an Android SDK/Gradle environment for `expo prebuild` and native compilation. Source validation is not equivalent to a successful APK build.
