# Aamshu v2 security model

## API
- Helmet security headers
- CORS allow-list
- JSON body limits
- IP rate limiting
- Password hashing with bcrypt
- Signed JWT sessions
- Project ownership checks

## Execution
The default sandbox is disabled.

When enabled, the Docker adapter applies:
- no network
- memory limit
- CPU limit
- process limit
- read-only root filesystem
- dropped Linux capabilities
- no-new-privileges
- non-root runner image

For public production, move execution to a dedicated runner service. Do not mount `/var/run/docker.sock` into a public API container.

## Secrets
Never ship JWT secrets, database credentials, signing keys, or backend master API keys in the mobile binary.
