# Aamshu Multi-Agent Development Workforce

Aamshu can decompose a development request into bounded specialist jobs and route them through an auditable coordinator.

## Workers
- Architect: decomposition, interfaces, dependency decisions.
- Android Engineer: native Android, services, permissions.
- Backend Engineer: APIs, database, authentication.
- AI Engineer: provider integration, prompts, streaming.
- Voice Engineer: speech recognition, TTS, audio lifecycle.
- Security Engineer: defensive threat modeling and hardening.
- UI Engineer: React Native UI/UX and accessibility.
- QA Engineer: tests, regression, validation.
- Reviewer: conflict/risk review and release gate.

## Workflow
1. `POST /api/development/workforce/plan` creates a task plan.
2. The Architect runs first.
3. Independent specialists fan out after architecture is completed.
4. Failed jobs retry up to three attempts.
5. Reviewer runs only after all specialist jobs complete.
6. Release readiness must be explicitly approved by the reviewer.

## Guardrails
- Workers are not granted unrestricted device, shell, filesystem, credential, or network access.
- Consequential Android actions remain behind the existing permission/confirmation system.
- AI credentials remain server-side.
- Security work is defensive: threat modeling, abuse prevention, hardening, logging, and containment—not offensive intrusion or retaliation.
- The orchestrator tracks job IDs, dependencies, attempts, status, and results.

## Future provider execution
The workforce planner is intentionally provider-neutral. A future worker adapter can dispatch jobs to one or more approved AI providers/models in parallel while preserving the same job contract and reviewer gate.
