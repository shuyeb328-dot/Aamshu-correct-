# Aamshu v2.4 Memory + Voice Architecture

Aamshu now supports selective persistent companion context. It stores only explicit, useful preferences or project context detected from clear user phrasing. It does not store hidden reasoning, inferred sensitive traits, or private chain-of-thought.

## Memory
- User-scoped SQLite table: `companion_memories`
- Deduplicated by user/kind/content
- Maximum 40 recent records supplied to the model
- Individual records are capped at 600 characters
- Relevant memory is injected server-side only

## Voice
The existing native speech recognition + TTS path remains unchanged. Aamshu v2.6 now uses an authenticated SSE streaming transport for incremental model text. Voice playback still waits for the completed text response because token streaming and audio streaming are separate features.

## Security
Provider credentials remain server-side. Memory is never sent to the client as a hidden system prompt. Production deployments should provide account-level memory controls and deletion endpoints before public release.

## v2.5 memory controls

Authenticated users can inspect and remove companion memories:
- `GET /api/companion/memories`
- `DELETE /api/companion/memories/:id`
- `DELETE /api/companion/memories/`

Memory is scoped to the authenticated account. Clearing companion memory does not delete project memories or conversation history.
