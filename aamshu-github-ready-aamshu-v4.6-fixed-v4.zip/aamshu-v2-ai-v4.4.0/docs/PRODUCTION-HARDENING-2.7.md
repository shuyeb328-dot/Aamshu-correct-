# Aamshu v2.7 production hardening

- AI provider URLs are validated; production requires HTTPS.
- AI output is bounded by `AI_MAX_OUTPUT_CHARS` (default 12,000).
- Companion requests are rate-limited per authenticated account: 30/minute for normal replies and 20/minute for streaming.
- Streaming stops work when the client disconnects.
- AI credentials remain server-side.
- Companion memory remains explicit-only, account-scoped, and user-deletable.
- `/api/status` reports whether the provider is actually configured and whether streaming is available.
- No AI key is placed in Expo config or APK assets.
- Code execution remains disabled unless the isolated runner is explicitly enabled.

Before public release: configure HTTPS, a strong JWT secret, explicit CORS origins, a real AI provider, database backups, monitoring, and a dedicated isolated execution runner if code execution is enabled.
