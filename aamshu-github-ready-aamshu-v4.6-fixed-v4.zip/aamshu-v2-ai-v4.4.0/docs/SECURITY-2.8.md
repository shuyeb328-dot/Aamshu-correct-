# Aamshu v2.8 Security Defense Layer

Aamshu uses layered defensive controls rather than offensive counterattacks.

## Covered threats
- credential stuffing and repeated authentication failures
- stolen/revoked sessions
- oversized requests and malformed JSON
- suspicious URL/path traversal markers
- common script/injection markers in JSON input
- unsafe AI-provider endpoints, including private-network destinations
- runaway AI output and request volume
- secret leakage in security audit logs
- client disconnects during streaming
- sandbox escape risk through the runner's existing isolation controls

## Defensive response
1. Reject malformed or suspicious requests.
2. Rate-limit authentication and AI workloads.
3. Revoke server-side sessions when compromise is suspected.
4. Record redacted security audit events.
5. Keep provider credentials server-side.
6. Block AI provider URLs that resolve to private/local addresses.
7. Stop long-running streams when the client disconnects.
8. Keep code execution isolated and disabled by default.
9. Rotate JWT/provider credentials after suspected compromise.
10. Preserve logs for investigation without storing passwords or bearer tokens.

Aamshu does not perform retaliation, unauthorized scanning, exploitation, persistence, credential theft, or attacks against suspected attackers. Incident response is containment, revocation, logging, recovery, and lawful investigation.


## Security layers

| Layer | Defense | Response |
|---|---|---|
| Edge | CORS allow-list, Helmet, body limits, rate limits | Reject/slow abusive traffic |
| Request | request IDs, malformed-path rejection, strict JSON | Reject and audit |
| Authentication | bcrypt, short-lived JWTs, issuer/algorithm pinning, server-side sessions | Reject/revoke |
| Session | individual logout and logout-all | Immediate revocation |
| AI | HTTPS-only production providers, private-network resolution block, output/time limits | Refuse unsafe provider |
| Streaming | bounded deltas, timeout, disconnect handling | Stop stream |
| Data | parameterized SQLite queries, foreign keys, account scoping | Prevent cross-user access |
| Memory | explicit useful context only, user deletion | Delete/revoke |
| Execution | Docker isolation, network disabled, read-only filesystem, dropped capabilities | Disable/contain |
| Secrets | environment/server only, redacted audit logs | Rotate after compromise |

## Incident response

If compromise is suspected: revoke all sessions, rotate JWT and AI-provider credentials, disable execution/sandbox access, preserve redacted logs, inspect the affected host and dependencies, patch the root cause, and only then restore service. Do not retaliate against a suspected attacker.
