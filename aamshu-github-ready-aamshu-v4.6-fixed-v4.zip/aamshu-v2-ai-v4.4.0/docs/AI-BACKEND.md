# Aamshu AI Backend

Aamshu v2.3 supports an optional server-side AI provider through an OpenAI-compatible Chat Completions endpoint.

## Configuration

Set these variables on the server only:

- `AI_PROVIDER=openai-compatible`
- `AI_API_URL=https://provider.example.com/v1`
- `AI_API_KEY=...`
- `AI_MODEL=...`
- `AI_TIMEOUT_MS=20000`

The APK never receives the provider key. The mobile app continues to call `/api/companion/reply`.

## Fallback

If no provider is configured or the provider fails, Aamshu automatically uses its deterministic companion response layer. This keeps the app usable during outages and development.

## Safety

The server sends language, mode, intent, tone, goal, urgency and response-style metadata to the model. It does not send private chain-of-thought. The provider prompt explicitly asks for respectful, non-violent and non-dependent companion behavior.
