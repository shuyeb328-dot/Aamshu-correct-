# Aamshu Multi-Agent Artifact Runtime 4.4

Workers can receive bounded project artifacts, filtered by specialist role, and return structured patch proposals.

## Flow

Request → Architect → specialist workers → artifact proposals → QA/Security/Reviewer → release gate

## Safety
- Artifact paths reject absolute paths, traversal (`..`), null bytes, and unsafe characters.
- Content and total artifact sizes are bounded.
- Workers receive selected artifacts rather than unrestricted filesystem access.
- Worker patch proposals are proposals only; the runtime does not blindly apply them.
- AI output is bounded and treated as untrusted project data.

## API
`POST /api/development-workforce/:id/run` accepts optional `context` and bounded `artifacts` entries (`path`, `content`, `type`).

The response includes artifact summaries and each worker result can contain `patch_proposals` and `artifact_refs`.

## Provider modes
- `openai-compatible`: dispatches worker prompts to the configured provider.
- `mock`: deterministic local worker behavior when no provider is configured.

This release does not claim filesystem mutation or autonomous code deployment.
