const {
  withAndroidManifest,
  withDangerousMod,
} = require("@expo/config-plugins");

const fs = require("fs");
const path = require("path");

function copyNative(projectRoot, platformProjectRoot) {
  const src = path.join(projectRoot, "native", "android", "com", "aamshu", "assistant");
  const dst = path.join(platformProjectRoot, "app", "src", "main", "java", "com", "aamshu", "assistant");

  if (!fs.existsSync(src)) throw new Error(`Aamshu native source not found: ${src}`);
  fs.mkdirSync(dst, { recursive: true });

  for (const file of fs.readdirSync(src)) {
    const sourceFile = path.join(src, file);
    const destinationFile = path.join(dst, file);
    if (fs.statSync(sourceFile).isFile()) fs.copyFileSync(sourceFile, destinationFile);
  }
}

function findMainApplication(androidRoot) {
  const javaRoot = path.join(androidRoot, "app", "src", "main", "java");
  function walk(dir) {
    if (!fs.existsSync(dir)) return null;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        const result = walk(fullPath);
        if (result) return result;
      } else if (entry.isFile() && (entry.name === "MainApplication.kt" || entry.name === "MainApplication.java")) {
        return fullPath;
      }
    }
    return null;
  }
  return walk(javaRoot);
}

function addImport(contents) {
  const importLine = "import com.aamshu.assistant.AamshuAssistantPackage;";
  if (contents.includes("com.aamshu.assistant.AamshuAssistantPackage")) return contents;

  const packageMatch = contents.match(/^package\s+[^;\n]+;?\s*$/m);
  if (!packageMatch) throw new Error("Could not locate package declaration in MainApplication.");

  return contents.replace(packageMatch[0], `${packageMatch[0]}\n\n${importLine}`);
}

function patchMainApplication(projectRoot, androidRoot) {
  copyNative(projectRoot, androidRoot);

  const mainApplication = findMainApplication(androidRoot);
  if (!mainApplication) throw new Error("Could not locate MainApplication.kt or MainApplication.java.");

  let contents = fs.readFileSync(mainApplication, "utf8");
  if (contents.includes("com.aamshu.assistant.AamshuAssistantPackage")) {
    console.log("AamshuAssistantPackage already registered.");
    return;
  }

  // Android/Kotlin source needs a Kotlin-compatible import (without Java semicolon).
  if (mainApplication.endsWith(".kt")) {
    const importLine = "import com.aamshu.assistant.AamshuAssistantPackage";
    const packageMatch = contents.match(/^package\s+[^\n]+\n/m);
    if (!packageMatch) throw new Error("Could not locate package declaration in MainApplication.kt.");
    contents = contents.replace(packageMatch[0], `${packageMatch[0]}\n${importLine}\n`);

    const patterns = [
      /val packages = PackageList\(this\)\.packages\.toMutableList\(\)/,
      /PackageList\(this\)\.packages\.toMutableList\(\)/,
    ];

    for (const pattern of patterns) {
      if (pattern.test(contents)) {
        contents = contents.replace(
          pattern,
          `val packages = PackageList(this).packages.toMutableList().apply {\n            add(AamshuAssistantPackage())\n          }`
        );
        fs.writeFileSync(mainApplication, contents);
        console.log("Patched Kotlin MainApplication.");
        return;
      }
    }

    throw new Error("Could not locate Kotlin PackageList in MainApplication.kt.");
  }

  // Java
  contents = addImport(contents);
  const javaPattern = /List<ReactPackage>\s+packages\s*=\s*new\s+PackageList\(this\)\.getPackages\(\);/;
  if (javaPattern.test(contents)) {
    contents = contents.replace(javaPattern, `$&\n          packages.add(new AamshuAssistantPackage());`);
    fs.writeFileSync(mainApplication, contents);
    console.log("Patched Java MainApplication.");
    return;
  }

  throw new Error("Could not locate Java React Native PackageList in MainApplication.java.");
}

module.exports = function withAamshuNative(config) {
  config = withAndroidManifest(config, (config) => {
    const app = config.modResults.manifest.application?.[0];
    if (app) {
      app.service = app.service || [];
      app.receiver = app.receiver || [];

      if (!app.receiver.some((x) => x?.["$"]?.["android:name"] === ".assistant.AamshuAssistantReceiver")) {
        app.receiver.push({ $: { "android:name": ".assistant.AamshuAssistantReceiver", "android:exported": "false" } });
      }

      if (!app.service.some((x) => x?.["$"]?.["android:name"] === ".assistant.AamshuAssistantService")) {
        app.service.push({ $: {
          "android:name": ".assistant.AamshuAssistantService",
          "android:exported": "false",
          "android:foregroundServiceType": "microphone",
          "android:stopWithTask": "true",
        }});
      }
    }
    return config;
  });

  config = withDangerousMod(config, ["android", async (config) => {
    patchMainApplication(config.modRequest.projectRoot, config.modRequest.platformProjectRoot);
    return config;
  }]);

  return config;
};
