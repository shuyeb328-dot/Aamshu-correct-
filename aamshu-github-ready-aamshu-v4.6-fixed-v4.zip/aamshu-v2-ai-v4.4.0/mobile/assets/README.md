# Aamshu v2 branding assets

- `icon.png` — primary Android/iOS app icon.
- `adaptive-icon.png` — safe-zone Android adaptive foreground.
- `splash.png` — dark launch artwork.

These assets use the finalized Aamshu AI logo.
