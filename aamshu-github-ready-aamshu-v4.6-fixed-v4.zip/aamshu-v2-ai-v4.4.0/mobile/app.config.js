const production = process.env.APP_ENV === "production";
module.exports = {
  expo: {
    name:"Aamshu Personal Assistant",
    slug:"aamshu-v2",
    version:"4.6.0",
    orientation:"portrait",
    userInterfaceStyle:"dark",
    scheme:"aamshu",
    icon:"./assets/icon.png",
    splash:{image:"./assets/splash.png",resizeMode:"contain",backgroundColor:"#0B1020"},
    android:{
      package:"com.aamshu.mobile",
      versionCode:18,
      adaptiveIcon:{foregroundImage:"./assets/adaptive-icon.png",backgroundColor:"#0B1020"},
      permissions:["INTERNET","ACCESS_NETWORK_STATE","VIBRATE","RECORD_AUDIO","FOREGROUND_SERVICE","FOREGROUND_SERVICE_MICROPHONE"],
      usesCleartextTraffic:!production
    },
    plugins:["@react-native-voice/voice","./plugins/withAamshuNative"],
    extra:{
      apiBaseUrl:process.env.EXPO_PUBLIC_API_URL || "",
      appEnvironment:process.env.APP_ENV || "development",
      eas:{projectId:process.env.EAS_PROJECT_ID || undefined}
    }
  }
};
