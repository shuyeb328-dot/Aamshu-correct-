package com.aamshu.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;

public class AamshuAssistantService extends Service {
    public static final String CHANNEL_ID = "aamshu_assistant";
    public static final int NOTIFICATION_ID = 7401;
    public static final String ACTION_OPEN = "com.aamshu.assistant.OPEN";
    public static final String ACTION_VOICE = "com.aamshu.assistant.VOICE";
    public static final String ACTION_STOP = "com.aamshu.assistant.STOP";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
    }

    private PendingIntent serviceAction(String action, int requestCode) {
        Intent intent = new Intent(this, AamshuAssistantReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(this, requestCode, intent,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent open = launch == null ? null : PendingIntent.getActivity(this, 0, launch,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Aamshu Assistant")
                .setContentText("Assistant is active. Voice activation is user-controlled.")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Voice", serviceAction(ACTION_VOICE, 7402)).build())
                .addAction(new Notification.Action.Builder(null, "Stop", serviceAction(ACTION_STOP, 7403)).build());
        if (open != null) b.setContentIntent(open);
        return b.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Aamshu Assistant", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Visible notification for the active Aamshu assistant service.");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }

    @Override public void onDestroy() {
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
