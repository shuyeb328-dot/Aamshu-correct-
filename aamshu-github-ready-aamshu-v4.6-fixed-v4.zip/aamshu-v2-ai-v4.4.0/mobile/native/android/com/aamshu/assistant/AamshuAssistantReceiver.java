package com.aamshu.assistant;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class AamshuAssistantReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (AamshuAssistantService.ACTION_STOP.equals(action)) {
            context.stopService(new Intent(context, AamshuAssistantService.class));
            AamshuAssistantModule.setActive(false);
            return;
        }
        if (AamshuAssistantService.ACTION_VOICE.equals(action)) {
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            if (launch != null) {
                launch.setData(Uri.parse("aamshu://assistant?action=voice"));
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(launch);
            }
        }
    }
}
