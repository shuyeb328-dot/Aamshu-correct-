package com.aamshu.assistant;

import android.content.Intent;
import android.os.Build;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class AamshuAssistantModule extends ReactContextBaseJavaModule {
    private static volatile boolean active = false;
    static void setActive(boolean value) { active = value; }
    public AamshuAssistantModule(ReactApplicationContext context) { super(context); }
    @Override public String getName() { return "AamshuAssistant"; }

    @ReactMethod public void startAssistant(Promise promise) {
        try {
            Intent intent = new Intent(getReactApplicationContext(), AamshuAssistantService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getReactApplicationContext().startForegroundService(intent);
            else getReactApplicationContext().startService(intent);
            setActive(true);
            promise.resolve(true);
        } catch (Exception e) { promise.reject("ASSISTANT_START_FAILED", e); }
    }

    @ReactMethod public void stopAssistant(Promise promise) {
        try {
            Intent intent = new Intent(getReactApplicationContext(), AamshuAssistantService.class);
            getReactApplicationContext().stopService(intent);
            setActive(false);
            promise.resolve(true);
        } catch (Exception e) { promise.reject("ASSISTANT_STOP_FAILED", e); }
    }

    @ReactMethod public void isAssistantActive(Promise promise) { promise.resolve(active); }

    @ReactMethod public void requestVoiceFromAssistant(Promise promise) {
        try {
            Intent launch = getReactApplicationContext().getPackageManager().getLaunchIntentForPackage(getReactApplicationContext().getPackageName());
            if (launch == null) throw new IllegalStateException("App launch intent unavailable");
            launch.setData(android.net.Uri.parse("aamshu://assistant?action=voice"));
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            getReactApplicationContext().startActivity(launch);
            promise.resolve(true);
        } catch (Exception e) { promise.reject("VOICE_REQUEST_FAILED", e); }
    }
}
