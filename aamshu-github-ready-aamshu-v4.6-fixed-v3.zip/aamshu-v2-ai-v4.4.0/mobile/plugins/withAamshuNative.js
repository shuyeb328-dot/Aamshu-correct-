const { withAndroidManifest, withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

function copyNative(projectRoot, platformProjectRoot) {
  const src = path.join(projectRoot, 'native/android/com/aamshu/assistant');
  const dst = path.join(platformProjectRoot, 'app/src/main/java/com/aamshu/assistant');
  if (!fs.existsSync(src)) throw new Error(`Aamshu native source not found: ${src}`);
  fs.mkdirSync(dst, { recursive: true });
  for (const file of fs.readdirSync(src)) {
    fs.copyFileSync(path.join(src, file), path.join(dst, file));
  }
}

function findFile(root, name) {
  if (!fs.existsSync(root)) return null;
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const full = path.join(root, entry.name);
    if (entry.isDirectory()) {
      const found = findFile(full, name);
      if (found) return found;
    } else if (entry.name === name) return full;
  }
  return null;
}

function patchMainApplication(projectRoot, platformProjectRoot) {
  copyNative(projectRoot, platformProjectRoot);
  const javaRoot = path.join(platformProjectRoot, 'app/src/main/java');
  const mainJava = findFile(javaRoot, 'MainApplication.java');
  const mainKotlin = findFile(javaRoot, 'MainApplication.kt');
  const file = mainJava || mainKotlin;
  if (!file) throw new Error('Aamshu native plugin could not locate MainApplication.java or MainApplication.kt.');

  let contents = fs.readFileSync(file, 'utf8');
  const pkg = 'com.aamshu.assistant.AamshuAssistantPackage';
  if (contents.includes(pkg)) return;

  if (file.endsWith('.java')) {
    contents = contents.replace(/^(package .*?;\n|package .*?\n)/m, '$1\nimport com.aamshu.assistant.AamshuAssistantPackage;\n');
    const marker = 'List<ReactPackage> packages = new PackageList(this).getPackages();';
    if (contents.includes(marker)) {
      contents = contents.replace(marker, marker + '\n          packages.add(new AamshuAssistantPackage());');
    } else {
      throw new Error('Aamshu native plugin could not locate the Java React Native PackageList in MainApplication.');
    }
  } else {
    contents = contents.replace(/^(package .*?\n)/m, '$1\nimport com.aamshu.assistant.AamshuAssistantPackage\n');
    const marker = 'PackageList(this).packages.apply { addAll(packages) }';
    if (contents.includes(marker)) {
      contents = contents.replace(marker, marker + '\n          add(AamshuAssistantPackage())');
    } else if (contents.includes('PackageList(this).packages.toMutableList()')) {
      contents = contents.replace(/(PackageList\(this\)\.packages\.toMutableList\(\))/, '$1\n          packages.add(AamshuAssistantPackage())');
    } else {
      throw new Error('Aamshu native plugin could not locate the Kotlin React Native PackageList in MainApplication.');
    }
  }
  fs.writeFileSync(file, contents);
}

module.exports = function withAamshuNative(config) {
  config = withAndroidManifest(config, config => {
    const app = config.modResults.manifest.application?.[0];
    if (app) {
      app.service = app.service || [];
      app.receiver = app.receiver || [];
      if (!app.receiver.some(x => x.$?.['android:name'] === '.assistant.AamshuAssistantReceiver')) {
        app.receiver.push({ $: { 'android:name': '.assistant.AamshuAssistantReceiver', 'android:exported': 'false' } });
      }
      if (!app.service.some(x => x.$?.['android:name'] === '.assistant.AamshuAssistantService')) {
        app.service.push({ $: { 'android:name': '.assistant.AamshuAssistantService', 'android:exported': 'false', 'android:foregroundServiceType': 'microphone', 'android:stopWithTask': 'true' } });
      }
    }
    return config;
  });

  // Expo SDK 52 no longer exposes withMainApplication from config-plugins.
  // Use the supported dangerous Android mod to patch MainApplication after prebuild.
  config = withDangerousMod(config, ['android', async config => {
    patchMainApplication(config.modRequest.projectRoot, config.modRequest.platformProjectRoot);
    return config;
  }]);

  return config;
};
